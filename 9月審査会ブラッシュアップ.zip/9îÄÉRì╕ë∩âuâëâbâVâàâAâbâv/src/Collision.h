#pragma once
#include "ScreenMake.h"

bool BoxCollision(Vec2f pos1_, Vec2f size1_, Vec2f pos2_, Vec2f size2_);

bool CircleCollision(Vec2f pos1_, Vec2f size1_, Vec2f pos2_, Vec2f size2_);